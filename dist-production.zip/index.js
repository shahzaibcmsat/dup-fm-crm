var __defProp = Object.defineProperty;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __esm = (fn, res) => function __init() {
  return fn && (res = (0, fn[__getOwnPropNames(fn)[0]])(fn = 0)), res;
};
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};

// shared/schema.ts
var schema_exports = {};
__export(schema_exports, {
  companies: () => companies,
  companiesRelations: () => companiesRelations,
  emails: () => emails,
  emailsRelations: () => emailsRelations,
  insertCompanySchema: () => insertCompanySchema,
  insertEmailSchema: () => insertEmailSchema,
  insertInventorySchema: () => insertInventorySchema,
  insertLeadSchema: () => insertLeadSchema,
  insertMemberPermissionSchema: () => insertMemberPermissionSchema,
  insertNotificationSchema: () => insertNotificationSchema,
  insertUserSchema: () => insertUserSchema,
  inventory: () => inventory,
  leads: () => leads,
  leadsRelations: () => leadsRelations,
  loginSchema: () => loginSchema,
  memberPermissions: () => memberPermissions,
  notifications: () => notifications,
  users: () => users
});
import { sql } from "drizzle-orm";
import { pgTable, text, varchar, timestamp, boolean } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";
import { relations } from "drizzle-orm";
var users, companies, leads, emails, inventory, companiesRelations, leadsRelations, emailsRelations, insertCompanySchema, insertLeadSchema, insertEmailSchema, insertInventorySchema, notifications, memberPermissions, insertUserSchema, loginSchema, insertNotificationSchema, insertMemberPermissionSchema;
var init_schema = __esm({
  "shared/schema.ts"() {
    "use strict";
    users = pgTable("users", {
      id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
      username: text("username").notNull().unique(),
      email: text("email").notNull().unique(),
      passwordHash: text("password_hash").notNull(),
      role: text("role").notNull().default("user"),
      // 'admin' or 'user'
      isActive: boolean("is_active").notNull().default(true),
      createdAt: timestamp("created_at").notNull().defaultNow(),
      updatedAt: timestamp("updated_at").notNull().defaultNow()
    });
    companies = pgTable("companies", {
      id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
      name: text("name").notNull(),
      createdAt: timestamp("created_at").notNull().defaultNow(),
      updatedAt: timestamp("updated_at").notNull().defaultNow()
    });
    leads = pgTable("leads", {
      id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
      companyId: varchar("company_id").references(() => companies.id, { onDelete: "set null" }),
      clientName: text("client_name").notNull(),
      email: text("email").notNull(),
      phone: text("phone"),
      subject: text("subject"),
      leadDetails: text("lead_details"),
      notes: text("notes"),
      // Internal notes/comments for the lead
      status: text("status").notNull().default("New"),
      createdAt: timestamp("created_at").notNull().defaultNow(),
      updatedAt: timestamp("updated_at").notNull().defaultNow()
    });
    emails = pgTable("emails", {
      id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
      leadId: varchar("lead_id").notNull().references(() => leads.id, { onDelete: "cascade" }),
      subject: text("subject").notNull(),
      body: text("body").notNull(),
      direction: text("direction").notNull(),
      // 'sent' or 'received'
      messageId: text("message_id"),
      // Microsoft Graph Message ID for tracking
      conversationId: text("conversation_id"),
      // Thread ID for grouping
      inReplyTo: text("in_reply_to"),
      // Parent message ID
      fromEmail: text("from_email"),
      toEmail: text("to_email"),
      sentAt: timestamp("sent_at").notNull().defaultNow()
    });
    inventory = pgTable("inventory", {
      id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
      productHeading: text("product_heading"),
      // For section headers like "PARMA SPC"
      product: text("product").notNull(),
      boxes: text("boxes"),
      // stored as text to handle empty values and decimals
      sqFtPerBox: text("sq_ft_per_box"),
      // stored as text to handle decimal precision
      totalSqFt: text("total_sq_ft"),
      // stored as text to handle decimal precision
      notes: text("notes"),
      // For additional notes like "(drop)", "(NIFW)", "discontinued"
      createdAt: timestamp("created_at").notNull().defaultNow(),
      updatedAt: timestamp("updated_at").notNull().defaultNow()
    });
    companiesRelations = relations(companies, ({ many }) => ({
      leads: many(leads)
    }));
    leadsRelations = relations(leads, ({ many, one }) => ({
      emails: many(emails),
      company: one(companies, {
        fields: [leads.companyId],
        references: [companies.id]
      })
    }));
    emailsRelations = relations(emails, ({ one }) => ({
      lead: one(leads, {
        fields: [emails.leadId],
        references: [leads.id]
      })
    }));
    insertCompanySchema = createInsertSchema(companies).omit({
      id: true,
      createdAt: true,
      updatedAt: true
    });
    insertLeadSchema = createInsertSchema(leads).omit({
      id: true,
      createdAt: true,
      updatedAt: true
    });
    insertEmailSchema = createInsertSchema(emails).omit({
      id: true,
      sentAt: true
    });
    insertInventorySchema = z.object({
      product: z.string(),
      boxes: z.string().nullable(),
      sqFtPerBox: z.string().nullable(),
      totalSqFt: z.string().nullable(),
      productHeading: z.string().nullable(),
      notes: z.string().nullable()
    });
    notifications = pgTable("notifications", {
      id: text("id").primaryKey(),
      leadId: varchar("lead_id").notNull().references(() => leads.id, { onDelete: "cascade" }),
      leadName: text("lead_name").notNull(),
      fromEmail: text("from_email").notNull(),
      subject: text("subject").notNull(),
      isDismissed: boolean("is_dismissed").notNull().default(false),
      createdAt: timestamp("created_at").notNull().defaultNow(),
      dismissedAt: timestamp("dismissed_at")
    });
    memberPermissions = pgTable("member_permissions", {
      id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
      userId: varchar("user_id").notNull(),
      // References auth.users(id) in Supabase
      companyIds: text("company_ids").array().notNull().default(sql`'{}'::text[]`),
      // Array of company IDs
      canSeeInventory: boolean("can_see_inventory").notNull().default(false),
      createdAt: timestamp("created_at").notNull().defaultNow(),
      updatedAt: timestamp("updated_at").notNull().defaultNow()
    });
    insertUserSchema = createInsertSchema(users).omit({
      id: true,
      createdAt: true,
      updatedAt: true
    });
    loginSchema = z.object({
      username: z.string().min(1, "Username is required"),
      password: z.string().min(1, "Password is required")
    });
    insertNotificationSchema = createInsertSchema(notifications);
    insertMemberPermissionSchema = createInsertSchema(memberPermissions).omit({
      id: true,
      createdAt: true,
      updatedAt: true
    });
  }
});

// server/db.ts
var db_exports = {};
__export(db_exports, {
  db: () => db,
  pool: () => pool
});
import { Pool, neonConfig } from "@neondatabase/serverless";
import { drizzle } from "drizzle-orm/neon-serverless";
import ws from "ws";
var connectionString, pool, db;
var init_db = __esm({
  "server/db.ts"() {
    "use strict";
    init_schema();
    neonConfig.webSocketConstructor = ws;
    connectionString = process.env.SUPABASE_DATABASE_URL || process.env.DATABASE_URL;
    if (!connectionString) {
      throw new Error(
        "SUPABASE_DATABASE_URL or DATABASE_URL must be set. Did you forget to provision a database?"
      );
    }
    pool = new Pool({
      connectionString,
      max: 20,
      // Maximum number of clients in the pool
      idleTimeoutMillis: 3e4,
      // Close idle clients after 30s
      connectionTimeoutMillis: 1e4
      // Timeout for new connections after 10s
    });
    db = drizzle({ client: pool, schema: schema_exports });
  }
});

// server/storage.ts
var storage_exports = {};
__export(storage_exports, {
  DatabaseStorage: () => DatabaseStorage,
  storage: () => storage
});
import { eq, desc, inArray } from "drizzle-orm";
var DatabaseStorage, storage;
var init_storage = __esm({
  "server/storage.ts"() {
    "use strict";
    init_schema();
    init_db();
    DatabaseStorage = class {
      async getAllLeads() {
        const result = await db.select({
          lead: leads,
          company: companies
        }).from(leads).leftJoin(companies, eq(leads.companyId, companies.id)).orderBy(desc(leads.createdAt));
        return result.map(({ lead, company }) => ({
          ...lead,
          company: company || null
        }));
      }
      async getLeadsByCompany(companyId) {
        const result = await db.select({
          lead: leads,
          company: companies
        }).from(leads).leftJoin(companies, eq(leads.companyId, companies.id)).where(eq(leads.companyId, companyId)).orderBy(desc(leads.createdAt));
        return result.map(({ lead, company }) => ({
          ...lead,
          company: company || null
        }));
      }
      async getLead(id) {
        const result = await db.select({
          lead: leads,
          company: companies
        }).from(leads).leftJoin(companies, eq(leads.companyId, companies.id)).where(eq(leads.id, id));
        if (result.length === 0) return void 0;
        const { lead, company } = result[0];
        return {
          ...lead,
          company: company || null
        };
      }
      async getLeadByEmail(email) {
        const [lead] = await db.select().from(leads).where(eq(leads.email, email));
        return lead || void 0;
      }
      async createLead(insertLead) {
        const [lead] = await db.insert(leads).values(insertLead).returning();
        return lead;
      }
      async updateLead(id, insertLead) {
        const [lead] = await db.update(leads).set({ ...insertLead, updatedAt: /* @__PURE__ */ new Date() }).where(eq(leads.id, id)).returning();
        return lead || void 0;
      }
      async updateLeadStatus(id, status) {
        const [lead] = await db.update(leads).set({ status, updatedAt: /* @__PURE__ */ new Date() }).where(eq(leads.id, id)).returning();
        return lead || void 0;
      }
      async updateLeadCompany(id, companyId) {
        console.log(`\u{1F4BE} Updating lead ${id} with companyId: ${companyId}`);
        const [lead] = await db.update(leads).set({ companyId, updatedAt: /* @__PURE__ */ new Date() }).where(eq(leads.id, id)).returning();
        console.log(`\u{1F4BE} Lead updated:`, lead);
        return lead || void 0;
      }
      async updateLeadNotes(id, notes) {
        const [lead] = await db.update(leads).set({ notes, updatedAt: /* @__PURE__ */ new Date() }).where(eq(leads.id, id)).returning();
        return lead || void 0;
      }
      async deleteLead(id) {
        await db.delete(emails).where(eq(emails.leadId, id));
        const result = await db.delete(leads).where(eq(leads.id, id)).returning();
        return result.length > 0;
      }
      async deleteLeads(ids) {
        if (ids.length === 0) return 0;
        await db.delete(emails).where(inArray(emails.leadId, ids));
        const result = await db.delete(leads).where(inArray(leads.id, ids)).returning();
        return result.length;
      }
      async getEmailsByLeadId(leadId) {
        return await db.select().from(emails).where(eq(emails.leadId, leadId)).orderBy(desc(emails.sentAt));
      }
      async getEmailByMessageId(messageId) {
        const [email] = await db.select().from(emails).where(eq(emails.messageId, messageId));
        return email || void 0;
      }
      async getEmailByConversationId(conversationId) {
        const [email] = await db.select().from(emails).where(eq(emails.conversationId, conversationId)).orderBy(desc(emails.sentAt)).limit(1);
        return email || void 0;
      }
      async createEmail(insertEmail) {
        const [email] = await db.insert(emails).values(insertEmail).returning();
        return email;
      }
      async createLeads(leadsList) {
        if (leadsList.length === 0) return [];
        return await db.insert(leads).values(leadsList).returning();
      }
      async getAllCompanies() {
        return await db.select().from(companies).orderBy(companies.name);
      }
      async getCompany(id) {
        const [company] = await db.select().from(companies).where(eq(companies.id, id));
        return company || void 0;
      }
      async createCompany(insertCompany) {
        const [company] = await db.insert(companies).values(insertCompany).returning();
        return company;
      }
      async updateCompany(id, insertCompany) {
        const [company] = await db.update(companies).set({ ...insertCompany, updatedAt: /* @__PURE__ */ new Date() }).where(eq(companies.id, id)).returning();
        return company || void 0;
      }
      async deleteCompany(id) {
        const result = await db.delete(companies).where(eq(companies.id, id)).returning();
        return result.length > 0;
      }
      async getAllInventory() {
        return await db.select().from(inventory).orderBy(desc(inventory.createdAt));
      }
      async getInventoryItem(id) {
        const [item] = await db.select().from(inventory).where(eq(inventory.id, id));
        return item || void 0;
      }
      async createInventoryItem(insertItem) {
        const [item] = await db.insert(inventory).values(insertItem).returning();
        return item;
      }
      async updateInventoryItem(id, insertItem) {
        const [item] = await db.update(inventory).set({ ...insertItem, updatedAt: /* @__PURE__ */ new Date() }).where(eq(inventory.id, id)).returning();
        return item || void 0;
      }
      async deleteInventoryItem(id) {
        const result = await db.delete(inventory).where(eq(inventory.id, id)).returning();
        return result.length > 0;
      }
      async deleteInventoryItems(ids) {
        if (ids.length === 0) return 0;
        const result = await db.delete(inventory).where(inArray(inventory.id, ids)).returning();
        return result.length;
      }
      async createInventoryItems(items) {
        if (items.length === 0) return [];
        return await db.insert(inventory).values(items).returning();
      }
      // Member Permissions
      async getMemberPermissions(userId) {
        const [permission] = await db.select().from(memberPermissions).where(eq(memberPermissions.userId, userId));
        return permission || void 0;
      }
      async getAllMemberPermissions() {
        return await db.select().from(memberPermissions);
      }
      async upsertMemberPermissions(insertPermission) {
        const existing = await this.getMemberPermissions(insertPermission.userId);
        if (existing) {
          const [updated] = await db.update(memberPermissions).set({
            companyIds: insertPermission.companyIds,
            canSeeInventory: insertPermission.canSeeInventory,
            updatedAt: /* @__PURE__ */ new Date()
          }).where(eq(memberPermissions.userId, insertPermission.userId)).returning();
          return updated;
        } else {
          const [created] = await db.insert(memberPermissions).values(insertPermission).returning();
          return created;
        }
      }
      async deleteMemberPermissions(userId) {
        const result = await db.delete(memberPermissions).where(eq(memberPermissions.userId, userId)).returning();
        return result.length > 0;
      }
      // Notification methods
      async createNotification(notification) {
        const [created] = await db.insert(notifications).values(notification).returning();
        return created;
      }
      async getRecentNotifications(since) {
        const query = db.select().from(notifications).where(eq(notifications.isDismissed, false)).orderBy(desc(notifications.createdAt)).limit(50);
        return await query;
      }
      async dismissNotification(id) {
        const result = await db.update(notifications).set({
          isDismissed: true,
          dismissedAt: /* @__PURE__ */ new Date()
        }).where(eq(notifications.id, id)).returning();
        return result.length > 0;
      }
      async dismissNotificationsByLead(leadId) {
        const result = await db.update(notifications).set({
          isDismissed: true,
          dismissedAt: /* @__PURE__ */ new Date()
        }).where(eq(notifications.leadId, leadId)).returning();
        return result.length;
      }
      async cleanupOldNotifications() {
        const sevenDaysAgo = new Date(Date.now() - 7 * 24 * 60 * 60 * 1e3);
        const result = await db.delete(notifications).where(eq(notifications.isDismissed, true)).returning();
        return result.length;
      }
    };
    storage = new DatabaseStorage();
  }
});

// server/gmail.ts
var gmail_exports = {};
__export(gmail_exports, {
  fetchNewEmails: () => fetchNewEmails,
  getEmailBody: () => getEmailBody,
  getEmailById: () => getEmailById,
  getHeader: () => getHeader,
  getInReplyToHeader: () => getInReplyToHeader,
  isGmailConfigured: () => isGmailConfigured,
  sendEmail: () => sendEmail
});
import { google } from "googleapis";
function getGmailConfig() {
  const clientId = process.env.GMAIL_CLIENT_ID;
  const clientSecret = process.env.GMAIL_CLIENT_SECRET;
  const redirectUri = process.env.GMAIL_REDIRECT_URI || "http://localhost:5000/api/auth/callback";
  const refreshToken = process.env.GMAIL_REFRESH_TOKEN;
  if (!clientId || !clientSecret || !refreshToken) {
    console.log("\u26A0\uFE0F  Gmail not configured - missing credentials");
    return null;
  }
  return { clientId, clientSecret, redirectUri, refreshToken };
}
function createOAuth2Client() {
  const config = getGmailConfig();
  if (!config) return null;
  const oauth2Client = new google.auth.OAuth2(
    config.clientId,
    config.clientSecret,
    config.redirectUri
  );
  oauth2Client.setCredentials({
    refresh_token: config.refreshToken
  });
  return oauth2Client;
}
async function sendEmail(to, subject, body, fromEmail, inReplyTo) {
  console.log("\n\u{1F4E7} ========== GMAIL SEND ATTEMPT ==========");
  console.log("To:", to);
  console.log("Subject:", subject);
  console.log("From:", fromEmail || process.env.EMAIL_FROM_ADDRESS);
  if (inReplyTo) console.log("\u{1F9F5} In-Reply-To:", inReplyTo);
  const oauth2Client = createOAuth2Client();
  if (!oauth2Client) {
    console.log("\u26A0\uFE0F  No Gmail OAuth client available - logging email instead");
    console.log("=== EMAIL SENT (No Gmail configured) ===");
    console.log(`From: ${fromEmail || "noreply@example.com"}`);
    console.log(`To: ${to}`);
    console.log(`Subject: ${subject}`);
    console.log(`Body: ${body}`);
    console.log("=========================================\n");
    return {
      success: true,
      message: "Email logged (Gmail not configured)",
      details: { to, subject, body }
    };
  }
  try {
    const gmail = google.gmail({ version: "v1", auth: oauth2Client });
    const sendFromUser = fromEmail || process.env.EMAIL_FROM_ADDRESS || "me";
    const messageParts = [
      `From: ${sendFromUser}`,
      `To: ${to}`,
      `Subject: ${subject}`,
      "Content-Type: text/plain; charset=utf-8",
      "MIME-Version: 1.0"
    ];
    if (inReplyTo) {
      messageParts.push(`In-Reply-To: ${inReplyTo}`);
      messageParts.push(`References: ${inReplyTo}`);
    }
    messageParts.push("");
    messageParts.push(body);
    const message = messageParts.join("\n");
    const encodedMessage = Buffer.from(message).toString("base64").replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
    const response = await gmail.users.messages.send({
      userId: "me",
      requestBody: {
        raw: encodedMessage,
        threadId: inReplyTo ? void 0 : void 0
        // Let Gmail auto-thread
      }
    });
    console.log("\u2705 Email sent successfully via Gmail");
    console.log("   Message ID:", response.data.id);
    console.log("   Thread ID:", response.data.threadId);
    console.log("=========================================\n");
    return {
      success: true,
      message: "Email sent via Gmail",
      details: { to, subject, from: sendFromUser },
      messageId: response.data.id || void 0,
      conversationId: response.data.threadId || void 0
    };
  } catch (error) {
    console.error("\u274C Failed to send email via Gmail");
    console.error("   Error:", error.message);
    if (error.response?.data) {
      console.error("   Details:", JSON.stringify(error.response.data, null, 2));
    }
    console.log("=========================================\n");
    throw new Error(`Failed to send email: ${error.message}`);
  }
}
function isGmailConfigured() {
  return getGmailConfig() !== null;
}
async function fetchNewEmails(sinceDateTime) {
  const oauth2Client = createOAuth2Client();
  if (!oauth2Client) {
    console.log("\u26A0\uFE0F Cannot fetch emails - Gmail not configured");
    return [];
  }
  try {
    const gmail = google.gmail({ version: "v1", auth: oauth2Client });
    console.log("\u{1F4EC} Fetching new emails from Gmail inbox...");
    let query = "in:inbox";
    if (sinceDateTime) {
      const date = new Date(sinceDateTime);
      const formattedDate = date.toISOString().split("T")[0].replace(/-/g, "/");
      query += ` after:${formattedDate}`;
    }
    const listResponse = await gmail.users.messages.list({
      userId: "me",
      q: query,
      maxResults: 50
    });
    const messages = listResponse.data.messages || [];
    console.log(`\u{1F4EB} Found ${messages.length} emails`);
    const fullMessages = [];
    for (const message of messages) {
      if (message.id) {
        const fullMessage = await gmail.users.messages.get({
          userId: "me",
          id: message.id,
          format: "full"
        });
        fullMessages.push(fullMessage.data);
      }
    }
    return fullMessages;
  } catch (error) {
    console.error("\u274C Failed to fetch emails:", error.message);
    return [];
  }
}
async function getEmailById(messageId) {
  const oauth2Client = createOAuth2Client();
  if (!oauth2Client) {
    return null;
  }
  try {
    const gmail = google.gmail({ version: "v1", auth: oauth2Client });
    const response = await gmail.users.messages.get({
      userId: "me",
      id: messageId,
      format: "full"
    });
    return response.data;
  } catch (error) {
    console.error(`\u274C Failed to get email ${messageId}:`, error.message);
    return null;
  }
}
function getHeader(message, headerName) {
  if (!message.payload?.headers) return null;
  const header = message.payload.headers.find(
    (h) => h.name.toLowerCase() === headerName.toLowerCase()
  );
  return header?.value || null;
}
function getInReplyToHeader(message) {
  return getHeader(message, "In-Reply-To") || getHeader(message, "Message-ID");
}
function getEmailBody(message) {
  if (!message.payload) return "";
  const findTextPart = (parts) => {
    for (const part of parts) {
      if (part.mimeType === "text/plain" && part.body?.data) {
        return Buffer.from(part.body.data, "base64").toString("utf-8");
      }
      if (part.parts) {
        const text2 = findTextPart(part.parts);
        if (text2) return text2;
      }
    }
    return "";
  };
  if (message.payload.body?.data) {
    return Buffer.from(message.payload.body.data, "base64").toString("utf-8");
  }
  if (message.payload.parts) {
    return findTextPart(message.payload.parts);
  }
  return "";
}
var init_gmail = __esm({
  "server/gmail.ts"() {
    "use strict";
  }
});

// server/config-manager.ts
function initializeConfig() {
  runtimeConfig = {
    // Database
    DATABASE_URL: process.env.DATABASE_URL || "",
    // Gmail API (replaces Azure/Microsoft Graph)
    GMAIL_CLIENT_ID: process.env.GMAIL_CLIENT_ID || "",
    GMAIL_CLIENT_SECRET: process.env.GMAIL_CLIENT_SECRET || "",
    GMAIL_REFRESH_TOKEN: process.env.GMAIL_REFRESH_TOKEN || "",
    GMAIL_REDIRECT_URI: process.env.GMAIL_REDIRECT_URI || "",
    EMAIL_FROM_ADDRESS: process.env.EMAIL_FROM_ADDRESS || "",
    // Groq AI
    GROQ_API_KEY: process.env.GROQ_API_KEY || "",
    GROQ_MODEL: process.env.GROQ_MODEL || "llama-3.3-70b-versatile",
    // Server
    PORT: process.env.PORT || "5000",
    NODE_ENV: process.env.NODE_ENV || "development"
  };
  console.log("\u2705 Configuration system initialized");
}
function getConfig(key) {
  return runtimeConfig[key] || process.env[key] || "";
}
function getAllConfig(includeSensitive = false) {
  const config = {};
  for (const [key, value] of Object.entries(runtimeConfig)) {
    if (includeSensitive) {
      config[key] = value;
    } else {
      if (key.includes("SECRET") || key.includes("KEY") || key.includes("PASSWORD") || key.includes("URL")) {
        config[key] = value ? maskValue(value) : "";
      } else {
        config[key] = value;
      }
    }
  }
  return config;
}
function updateConfig(updates) {
  for (const [key, value] of Object.entries(updates)) {
    if (key in runtimeConfig) {
      if (value && value.includes("*")) {
        console.log(`\u23ED\uFE0F  Skipping masked value for ${key}`);
        continue;
      }
      runtimeConfig[key] = value;
      process.env[key] = value;
    }
  }
}
function saveConfigToFile(config) {
  try {
    updateConfig(config);
    const isProduction = process.env.NODE_ENV === "production";
    if (isProduction) {
      console.log("\u26A0\uFE0F Production mode: Configuration updated in memory only");
      console.log("\u{1F4A1} To persist changes, update environment variables in your hosting platform dashboard");
    } else {
      console.log("\u2139\uFE0F Development mode: Configuration updated in memory");
      console.log("\u{1F4A1} To persist changes across restarts, update your .env file manually");
    }
    return true;
  } catch (error) {
    console.error("\u274C Error updating runtime config:", error);
    return false;
  }
}
function maskValue(value) {
  if (!value || value.length < 8) {
    return "****";
  }
  return `${value.substring(0, 4)}${"*".repeat(value.length - 8)}${value.substring(value.length - 4)}`;
}
function validateConfig(config) {
  const errors = [];
  const isMaskedValue = (value) => value && value.includes("*");
  if (config.DATABASE_URL && !isMaskedValue(config.DATABASE_URL)) {
    if (!config.DATABASE_URL.startsWith("postgres://") && !config.DATABASE_URL.startsWith("postgresql://")) {
      errors.push("DATABASE_URL must be a valid PostgreSQL connection string");
    }
  }
  if (config.EMAIL_FROM_ADDRESS && !isMaskedValue(config.EMAIL_FROM_ADDRESS)) {
    if (!isValidEmail(config.EMAIL_FROM_ADDRESS)) {
      errors.push("EMAIL_FROM_ADDRESS must be a valid email address");
    }
  }
  if (config.PORT && isNaN(parseInt(config.PORT))) {
    errors.push("PORT must be a number");
  }
  if (config.GROQ_API_KEY && !isMaskedValue(config.GROQ_API_KEY)) {
    if (!config.GROQ_API_KEY.startsWith("gsk_")) {
      errors.push('GROQ_API_KEY should start with "gsk_"');
    }
  }
  return {
    valid: errors.length === 0,
    errors
  };
}
function isValidEmail(email) {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}
var runtimeConfig;
var init_config_manager = __esm({
  "server/config-manager.ts"() {
    "use strict";
    runtimeConfig = {};
    initializeConfig();
  }
});

// server/groq.ts
import Groq from "groq-sdk";
async function grammarFix(text2) {
  const apiKey = getConfig("GROQ_API_KEY");
  const model = getConfig("GROQ_MODEL") || "llama-3.3-70b-versatile";
  if (!apiKey) {
    throw new Error("GROQ_API_KEY is not set on the server");
  }
  const groq = new Groq({ apiKey });
  const system = `You are a concise grammar and clarity editor for business emails. Rewrite the user's text with correct grammar, punctuation, and tone while preserving meaning. Keep lists and formatting when present. Return compact, natural-sounding text. Respond ONLY with JSON: {"text": string, "suggestions": string[]} where suggestions explains notable changes.`;
  const user = `Text to improve:

${text2}`;
  const completion = await groq.chat.completions.create({
    model,
    temperature: 0.2,
    max_tokens: 600,
    messages: [
      { role: "system", content: system },
      { role: "user", content: user }
    ]
  });
  const content = completion.choices?.[0]?.message?.content?.trim() || "";
  let parsed = null;
  try {
    parsed = JSON.parse(content);
  } catch {
    const match = content.match(/\{[\s\S]*\}/);
    if (match) {
      try {
        parsed = JSON.parse(match[0]);
      } catch {
      }
    }
  }
  if (!parsed || typeof parsed.text !== "string") {
    return { text: text2, suggestions: [] };
  }
  const suggestions = Array.isArray(parsed.suggestions) ? parsed.suggestions.map((s) => String(s)).filter(Boolean) : [];
  return { text: parsed.text, suggestions };
}
async function generateAutoReply(params) {
  const apiKey = getConfig("GROQ_API_KEY");
  const model = getConfig("GROQ_MODEL") || "llama-3.1-70b-versatile";
  if (!apiKey) {
    throw new Error("GROQ_API_KEY is not set on the server");
  }
  const groq = new Groq({ apiKey });
  let contextParts = [];
  contextParts.push(`Lead Name: ${params.leadName}`);
  contextParts.push(`Lead Email: ${params.leadEmail}`);
  if (params.leadDescription) {
    contextParts.push(`
Lead Description/Notes:
${params.leadDescription}`);
  }
  if (params.conversationHistory && params.conversationHistory.length > 0) {
    contextParts.push(`
--- Email Conversation History (oldest to newest) ---`);
    params.conversationHistory.forEach((email, index) => {
      const direction = email.direction === "sent" ? "You sent" : `${params.leadName} sent`;
      contextParts.push(`
[${index + 1}] ${direction} - ${email.subject}`);
      contextParts.push(`${email.body.substring(0, 500)}${email.body.length > 500 ? "..." : ""}`);
    });
  }
  if (params.currentDraft && params.currentDraft.trim()) {
    contextParts.push(`
--- Your Draft So Far ---
${params.currentDraft}`);
  }
  const context = contextParts.join("\n");
  const system = `You are a professional business email assistant. Generate email replies in JSON format.

You must respond with ONLY a valid JSON object with this EXACT structure:
{"subject": "email subject line", "body": "email message content"}

Email writing guidelines:
- Read the provided lead information and conversation history
- If a draft is provided, incorporate and expand on it
- Write professionally but friendly
- Be concise and clear
- Address previous questions/concerns if any
- For replies, use 'Re: ' prefix in subject
- Don't include email signatures

IMPORTANT: Return ONLY the JSON object. No explanations, no markdown, no extra text.`;
  const user = `Context for email reply:

${context}

Return the JSON response now.`;
  let completion;
  try {
    completion = await groq.chat.completions.create({
      model,
      temperature: 0.7,
      max_tokens: 1e3,
      messages: [
        { role: "system", content: system },
        { role: "user", content: user }
      ]
    });
  } catch (error) {
    console.error("Groq API error:", error);
    throw new Error(`Failed to call Groq API: ${error.message}`);
  }
  const content = completion.choices?.[0]?.message?.content?.trim() || "";
  console.log("Groq AI raw response:", content);
  let parsed = null;
  try {
    parsed = JSON.parse(content);
  } catch {
    const match = content.match(/\{[\s\S]*\}/);
    if (match) {
      try {
        parsed = JSON.parse(match[0]);
        console.log("Successfully extracted JSON from response");
      } catch (e) {
        console.error("Failed to parse extracted JSON:", match[0]);
      }
    } else {
      console.error("No JSON object found in response");
    }
  }
  if (!parsed || typeof parsed.subject !== "string" || typeof parsed.body !== "string") {
    console.error("Invalid AI response format. Expected {subject: string, body: string}, got:", parsed);
    throw new Error("AI returned invalid format. Please try again.");
  }
  return { subject: parsed.subject, body: parsed.body };
}
var init_groq = __esm({
  "server/groq.ts"() {
    "use strict";
    init_config_manager();
  }
});

// server/routes.ts
import { createServer } from "http";
import multer from "multer";
import * as XLSX from "xlsx";
import { sql as sql2 } from "drizzle-orm";
async function registerRoutes(app2) {
  app2.get("/api/health", (req, res) => {
    res.json({ status: "ok", timestamp: (/* @__PURE__ */ new Date()).toISOString() });
  });
  app2.post("/api/grammar/fix", async (req, res) => {
    try {
      const { text: text2 } = req.body;
      if (!text2) {
        return res.status(400).json({ message: "Text is required" });
      }
      const result = await grammarFix(text2);
      res.json(result);
    } catch (error) {
      console.error("Grammar fix error:", error);
      res.status(500).json({ message: error.message });
    }
  });
  app2.post("/api/emails/generate-reply", async (req, res) => {
    try {
      const { leadId, currentDraft } = req.body;
      if (!leadId) {
        return res.status(400).json({ message: "Lead ID is required" });
      }
      const lead = await storage.getLead(leadId);
      if (!lead) {
        return res.status(404).json({ message: "Lead not found" });
      }
      const emails2 = await storage.getEmailsByLeadId(leadId);
      const conversationHistory = emails2.sort((a, b) => new Date(a.sentAt).getTime() - new Date(b.sentAt).getTime()).map((email) => ({
        direction: email.direction,
        subject: email.subject,
        body: email.body,
        timestamp: email.sentAt.toISOString()
      }));
      const result = await generateAutoReply({
        leadName: lead.clientName,
        leadEmail: lead.email,
        leadDescription: lead.leadDetails || void 0,
        conversationHistory: conversationHistory.length > 0 ? conversationHistory : void 0,
        currentDraft: currentDraft || void 0
      });
      res.json(result);
    } catch (error) {
      console.error("Auto-reply generation error:", error);
      res.status(500).json({ message: error.message });
    }
  });
  app2.get("/api/auth/status", async (req, res) => {
    res.json({
      emailProvider: "gmail",
      gmailConfigured: isGmailConfigured(),
      environment: {
        hasClientId: !!process.env.GMAIL_CLIENT_ID,
        hasClientSecret: !!process.env.GMAIL_CLIENT_SECRET,
        hasRefreshToken: !!process.env.GMAIL_REFRESH_TOKEN,
        fromAddress: process.env.EMAIL_FROM_ADDRESS || "not set"
      }
    });
  });
  app2.get("/api/debug/email-config", async (req, res) => {
    res.json({
      provider: "gmail",
      gmail: {
        configured: isGmailConfigured(),
        clientId: process.env.GMAIL_CLIENT_ID ? "Set (hidden)" : "Not set",
        clientSecret: process.env.GMAIL_CLIENT_SECRET ? "Set (hidden)" : "Not set",
        refreshToken: process.env.GMAIL_REFRESH_TOKEN ? "Set (hidden)" : "Not set",
        fromAddress: process.env.EMAIL_FROM_ADDRESS || "Not set",
        redirectUri: process.env.GMAIL_REDIRECT_URI || "http://localhost:5000/api/auth/callback"
      }
    });
  });
  app2.get("/api/debug/test-gmail", async (req, res) => {
    try {
      const { isGmailConfigured: isGmailConfigured2 } = await Promise.resolve().then(() => (init_gmail(), gmail_exports));
      if (!isGmailConfigured2()) {
        return res.json({
          success: false,
          error: "Gmail not configured. Please set GMAIL_CLIENT_ID, GMAIL_CLIENT_SECRET, and GMAIL_REFRESH_TOKEN"
        });
      }
      const fromAddress = process.env.EMAIL_FROM_ADDRESS;
      if (!fromAddress) {
        return res.json({ success: false, error: "EMAIL_FROM_ADDRESS not set" });
      }
      res.json({
        success: true,
        message: "Gmail is configured and ready",
        fromAddress
      });
    } catch (error) {
      res.json({
        success: false,
        error: error.message,
        code: error.code,
        suggestion: error.code === "Request_ResourceNotFound" ? "User/Mailbox does not exist in this tenant" : "Check if user has Exchange Online license"
      });
    }
  });
  app2.get("/api/leads", async (req, res) => {
    try {
      const leads2 = await storage.getAllLeads();
      res.json(leads2);
    } catch (error) {
      res.status(500).json({ message: error.message });
    }
  });
  app2.get("/api/leads/:id", async (req, res) => {
    try {
      const lead = await storage.getLead(req.params.id);
      if (!lead) {
        return res.status(404).json({ message: "Lead not found" });
      }
      res.json(lead);
    } catch (error) {
      res.status(500).json({ message: error.message });
    }
  });
  app2.post("/api/leads", async (req, res) => {
    try {
      const validatedData = insertLeadSchema.parse(req.body);
      const lead = await storage.createLead(validatedData);
      res.status(201).json(lead);
    } catch (error) {
      res.status(400).json({ message: error.message });
    }
  });
  app2.patch("/api/leads/:id", async (req, res) => {
    try {
      const validatedData = insertLeadSchema.parse(req.body);
      const lead = await storage.updateLead(req.params.id, validatedData);
      if (!lead) {
        return res.status(404).json({ message: "Lead not found" });
      }
      res.json(lead);
    } catch (error) {
      res.status(400).json({ message: error.message });
    }
  });
  app2.patch("/api/leads/:id/status", async (req, res) => {
    try {
      const { status } = req.body;
      if (!status) {
        return res.status(400).json({ message: "Status is required" });
      }
      const lead = await storage.updateLeadStatus(req.params.id, status);
      if (!lead) {
        return res.status(404).json({ message: "Lead not found" });
      }
      res.json(lead);
    } catch (error) {
      res.status(500).json({ message: error.message });
    }
  });
  app2.patch("/api/leads/:id/notes", async (req, res) => {
    try {
      const { notes } = req.body;
      if (notes === void 0) {
        return res.status(400).json({ message: "Notes field is required" });
      }
      const lead = await storage.updateLeadNotes(req.params.id, notes);
      if (!lead) {
        return res.status(404).json({ message: "Lead not found" });
      }
      res.json(lead);
    } catch (error) {
      res.status(500).json({ message: error.message });
    }
  });
  app2.delete("/api/leads/:id", async (req, res) => {
    try {
      const success = await storage.deleteLead(req.params.id);
      if (!success) {
        return res.status(404).json({ message: "Lead not found" });
      }
      res.json({ message: "Lead deleted successfully" });
    } catch (error) {
      res.status(500).json({ message: error.message });
    }
  });
  app2.post("/api/leads/bulk-delete", async (req, res) => {
    try {
      const { ids } = req.body;
      if (!ids || !Array.isArray(ids) || ids.length === 0) {
        return res.status(400).json({ message: "Lead IDs array is required" });
      }
      const deletedCount = await storage.deleteLeads(ids);
      res.json({
        message: `${deletedCount} lead(s) deleted successfully`,
        count: deletedCount
      });
    } catch (error) {
      res.status(500).json({ message: error.message });
    }
  });
  app2.post("/api/leads/bulk-assign-company", async (req, res) => {
    try {
      const { leadIds, companyId } = req.body;
      console.log("\u{1F4CB} Bulk assign company request:", { leadIds, companyId });
      if (!leadIds || !Array.isArray(leadIds) || leadIds.length === 0) {
        return res.status(400).json({ message: "Lead IDs array is required" });
      }
      const updatePromises = leadIds.map(async (leadId) => {
        console.log(`  Updating lead ${leadId} with companyId: ${companyId}`);
        const result = await storage.updateLeadCompany(leadId, companyId || null);
        console.log(`  Updated lead ${leadId}:`, result);
        return result;
      });
      const results = await Promise.all(updatePromises);
      console.log("\u2705 All leads updated:", results.length);
      res.json({
        message: `${leadIds.length} lead(s) assigned to company successfully`,
        count: leadIds.length
      });
    } catch (error) {
      console.error("\u274C Error assigning company:", error);
      res.status(500).json({ message: error.message });
    }
  });
  app2.post("/api/leads/:id/send-email", async (req, res) => {
    try {
      const lead = await storage.getLead(req.params.id);
      if (!lead) {
        return res.status(404).json({ message: "Lead not found" });
      }
      const { subject, body } = req.body;
      if (!subject || !body) {
        return res.status(400).json({ message: "Subject and body are required" });
      }
      const existingEmails = await storage.getEmailsByLeadId(lead.id);
      const lastEmail = existingEmails.length > 0 ? existingEmails.sort((a, b) => new Date(b.sentAt).getTime() - new Date(a.sentAt).getTime())[0] : null;
      console.log(`\u{1F4E7} Sending email via Gmail...`);
      if (lastEmail) {
        console.log(`\u{1F9F5} Found existing conversation - replying to thread`);
        console.log(`   Last Message ID: ${lastEmail.messageId}`);
        console.log(`   Conversation ID: ${lastEmail.conversationId}`);
      }
      let emailSubject = subject;
      if (lastEmail) {
        const baseSubject = lastEmail.subject.replace(/^Re:\s*/i, "");
        emailSubject = `Re: ${baseSubject}`;
      }
      const result = await sendEmail(
        lead.email,
        emailSubject,
        body,
        void 0,
        // fromEmail (use default)
        lastEmail?.messageId || void 0
        // inReplyTo for threading
      );
      if (lastEmail?.conversationId && !result.conversationId) {
        result.conversationId = lastEmail.conversationId;
      }
      const fromEmail = process.env.EMAIL_FROM_ADDRESS;
      const emailData = insertEmailSchema.parse({
        leadId: lead.id,
        subject: emailSubject,
        body,
        direction: "sent",
        messageId: result.messageId || null,
        conversationId: result.conversationId || null,
        fromEmail: fromEmail || null,
        toEmail: lead.email,
        inReplyTo: lastEmail?.messageId || null
      });
      const email = await storage.createEmail(emailData);
      await storage.updateLeadStatus(lead.id, "Contacted");
      res.json({ success: true, email });
    } catch (error) {
      console.error("Error sending email:", error);
      res.status(500).json({ message: error.message || "Failed to send email" });
    }
  });
  app2.get("/api/emails/:leadId", async (req, res) => {
    try {
      const emails2 = await storage.getEmailsByLeadId(req.params.leadId);
      res.json(emails2);
    } catch (error) {
      res.status(500).json({ message: error.message });
    }
  });
  app2.get("/api/notifications/emails", async (req, res) => {
    try {
      const { getRecentNotifications: getRecentNotifications2 } = await Promise.resolve().then(() => (init_index(), index_exports));
      const since = req.query.since;
      const notifications2 = await getRecentNotifications2(since);
      console.log(`\u{1F4E1} Notification request - since: ${since || "all"}, returning: ${notifications2.length} notifications`);
      if (notifications2.length > 0) {
        console.log(`   Notification IDs: ${notifications2.map((n) => n.id).join(", ")}`);
      }
      res.json({ notifications: notifications2 });
    } catch (error) {
      console.error("\u274C Error fetching notifications:", error);
      res.status(500).json({ message: error.message });
    }
  });
  app2.post("/api/notifications/dismiss/:leadId", async (req, res) => {
    try {
      const { dismissNotificationsForLead: dismissNotificationsForLead2 } = await Promise.resolve().then(() => (init_index(), index_exports));
      const { leadId } = req.params;
      console.log(`\u{1F515} Dismissing notifications for lead: ${leadId}`);
      await dismissNotificationsForLead2(leadId);
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ message: error.message });
    }
  });
  app2.post("/api/notifications/dismiss-id/:notificationId", async (req, res) => {
    try {
      const { dismissNotification: dismissNotification2 } = await Promise.resolve().then(() => (init_index(), index_exports));
      const { notificationId } = req.params;
      await dismissNotification2(notificationId);
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ message: error.message });
    }
  });
  app2.post("/api/notifications/clear", async (req, res) => {
    try {
      const { clearAllNotifications: clearAllNotifications2 } = await Promise.resolve().then(() => (init_index(), index_exports));
      clearAllNotifications2();
      res.json({ success: true, message: "All notifications cleared" });
    } catch (error) {
      console.error("Error clearing notifications:", error);
      res.status(500).json({ message: error.message || "Failed to clear notifications" });
    }
  });
  app2.post("/api/emails/sync", async (req, res) => {
    try {
      const { fetchNewEmails: fetchNewEmails2, getInReplyToHeader: getInReplyToHeader2, getEmailBody: getEmailBody2, getHeader: getHeader2 } = await Promise.resolve().then(() => (init_gmail(), gmail_exports));
      const { addEmailNotification: addEmailNotification2 } = await Promise.resolve().then(() => (init_index(), index_exports));
      const lastSyncTime = req.body.since || new Date(Date.now() - 24 * 60 * 60 * 1e3).toISOString();
      console.log(`\u{1F504} Manual sync requested since ${new Date(lastSyncTime).toLocaleString()}`);
      const newEmails = await fetchNewEmails2(lastSyncTime);
      let savedCount = 0;
      let matchedCount = 0;
      for (const email of newEmails) {
        const fromAddress = getHeader2(email, "From");
        const subject = getHeader2(email, "Subject");
        const messageId = email.id;
        const threadId = email.threadId;
        console.log(`  \u{1F4E7} Processing email from: ${fromAddress}`);
        console.log(`     Subject: ${subject || "(No Subject)"}`);
        console.log(`     Message ID: ${messageId}`);
        console.log(`     Thread ID: ${threadId || "none"}`);
        if (!fromAddress) {
          console.log(`     No from address, skipping`);
          continue;
        }
        const emailMatch = fromAddress.match(/<(.+?)>/) || [null, fromAddress];
        const cleanFromAddress = emailMatch[1] || fromAddress;
        const existing = await storage.getEmailByMessageId(messageId);
        if (existing) {
          console.log(`     Email already exists in database, skipping`);
          continue;
        }
        let lead = null;
        const inReplyToHeader = getInReplyToHeader2(email);
        if (threadId) {
          console.log(`     Looking for existing email with thread ID: ${threadId}`);
          const relatedEmail = await storage.getEmailByConversationId(threadId);
          if (relatedEmail) {
            console.log(`     Found related email in thread, using lead: ${relatedEmail.leadId}`);
            lead = await storage.getLead(relatedEmail.leadId);
            matchedCount++;
          }
        }
        if (!lead) {
          console.log(`     No thread match, looking for lead by email address`);
          lead = await storage.getLeadByEmail(cleanFromAddress);
          if (lead) {
            matchedCount++;
          }
        }
        if (lead) {
          console.log(`     Matched to lead: ${lead.clientName} (${lead.id})`);
          console.log(`     Saving new email to database...`);
          const emailBody = getEmailBody2(email);
          const emailData = insertEmailSchema.parse({
            leadId: lead.id,
            subject: subject || "(No Subject)",
            body: emailBody || "",
            direction: "received",
            messageId,
            conversationId: threadId || null,
            fromEmail: cleanFromAddress,
            toEmail: process.env.EMAIL_FROM_ADDRESS || null,
            inReplyTo: inReplyToHeader
          });
          await storage.createEmail(emailData);
          savedCount++;
          await storage.updateLeadStatus(lead.id, "Replied");
          const notification = await addEmailNotification2(lead.id, lead.clientName, cleanFromAddress, subject || "(No Subject)");
          console.log(`     Created notification ${notification.id} for ${lead.clientName}`);
        } else {
          console.log(`     No matching lead found for email: ${fromAddress}`);
        }
      }
      res.json({
        success: true,
        checked: newEmails.length,
        matched: matchedCount,
        saved: savedCount,
        lastSync: (/* @__PURE__ */ new Date()).toISOString()
      });
    } catch (error) {
      console.error("Error syncing emails:", error);
      res.status(500).json({ message: error.message });
    }
  });
  app2.post("/api/import/file", upload.single("file"), async (req, res) => {
    try {
      if (!req.file) {
        return res.status(400).json({ message: "No file uploaded" });
      }
      const workbook = XLSX.read(req.file.buffer, { type: "buffer" });
      const sheetName = workbook.SheetNames[0];
      const worksheet = workbook.Sheets[sheetName];
      const rawData = XLSX.utils.sheet_to_json(worksheet);
      console.log(`\u{1F4CA} Processing ${rawData.length} rows from Excel file`);
      if (rawData.length === 0) {
        return res.status(400).json({ message: "Excel file is empty" });
      }
      const firstRow = rawData[0];
      const actualColumns = Object.keys(firstRow);
      console.log("\u{1F4CB} Detected columns in Excel:", actualColumns);
      const getColumnValue = (row, possibleNames) => {
        for (const name of possibleNames) {
          if (row[name]) return String(row[name]).trim();
        }
        const rowKeys = Object.keys(row);
        for (const name of possibleNames) {
          const lowerName = name.toLowerCase();
          const matchingKey = rowKeys.find((key) => key.toLowerCase() === lowerName);
          if (matchingKey && row[matchingKey]) {
            return String(row[matchingKey]).trim();
          }
        }
        return "";
      };
      const leads2 = rawData.map((row, index) => {
        const clientName = getColumnValue(row, [
          "Name",
          "Client Name",
          "client_name",
          "name",
          "CLIENT NAME",
          "NAME"
        ]);
        const email = getColumnValue(row, [
          "Email",
          "email",
          "EMAIL",
          "E-mail",
          "e-mail"
        ]);
        const phone = getColumnValue(row, [
          "Phone Number",
          "Phone",
          "phone",
          "phone_number",
          "PHONE NUMBER",
          "PHONE"
        ]);
        const subject = getColumnValue(row, [
          "Subject",
          "subject",
          "SUBJECT"
        ]);
        const leadDetails = getColumnValue(row, [
          "Lead Description",
          "Lead Details",
          "Description",
          "lead_details",
          "description",
          "LEAD DESCRIPTION",
          "DESCRIPTION"
        ]);
        if (!clientName || !email) {
          console.log(`\u26A0\uFE0F Skipping row ${index + 2}: Missing name or email`, {
            clientName: clientName || "(empty)",
            email: email || "(empty)",
            rowData: row
          });
          return null;
        }
        if (!email.includes("@")) {
          console.log(`\u26A0\uFE0F Skipping row ${index + 2}: Invalid email format: ${email}`);
          return null;
        }
        console.log(`\u2705 Row ${index + 2}: ${clientName} <${email}>`);
        return {
          clientName,
          email,
          phone: phone || null,
          subject: subject || null,
          leadDetails: leadDetails || "",
          status: "New"
        };
      }).filter((lead) => lead !== null);
      if (leads2.length === 0) {
        return res.status(400).json({
          message: "No valid leads found. Ensure your Excel has 'Name' and 'Email' columns with data. Detected columns: " + actualColumns.join(", ")
        });
      }
      console.log(`\u2705 Found ${leads2.length} valid leads to import`);
      const existingLeads = await storage.getAllLeads();
      const existingEmails = new Set(existingLeads.map((lead) => lead.email.toLowerCase()));
      const emailCount = /* @__PURE__ */ new Map();
      leads2.forEach((lead) => {
        const email = lead.email.toLowerCase();
        emailCount.set(email, (emailCount.get(email) || 0) + 1);
      });
      const duplicatesWithinFile = Array.from(emailCount.entries()).filter(([_, count]) => count > 1).map(([email]) => email);
      const duplicateEmails = [];
      const fileInternalDuplicates = [];
      const processedFileEmails = /* @__PURE__ */ new Set();
      leads2.forEach((lead) => {
        const emailLower = lead.email.toLowerCase();
        if (existingEmails.has(emailLower)) {
          duplicateEmails.push(lead.email);
        }
        if (duplicatesWithinFile.includes(emailLower)) {
          if (!processedFileEmails.has(emailLower)) {
            processedFileEmails.add(emailLower);
            fileInternalDuplicates.push(lead.email);
          }
        }
      });
      console.log(`\u{1F4CA} Import Summary:`);
      console.log(`   - Total leads to import: ${leads2.length}`);
      console.log(`   - Database duplicates found: ${duplicateEmails.length}`);
      console.log(`   - File internal duplicates: ${fileInternalDuplicates.length}`);
      const validatedLeads = leads2.map((lead) => insertLeadSchema.parse(lead));
      const createdLeads = await storage.createLeads(validatedLeads);
      const createdCount = createdLeads.length;
      console.log(`\u2705 Successfully imported ${createdCount} leads`);
      res.json({
        success: true,
        total: leads2.length,
        imported: createdCount,
        duplicates: duplicateEmails.length,
        rejected: leads2.length - createdCount,
        summary: {
          totalRows: rawData.length,
          validRows: leads2.length,
          newLeads: createdCount,
          duplicateLeads: duplicateEmails.length,
          invalidRows: rawData.length - leads2.length,
          duplicateEmails,
          fileInternalDuplicates,
          rejectedCount: leads2.length - createdCount
        }
      });
    } catch (error) {
      console.error("\u274C Error importing file:", error);
      res.status(400).json({ message: error.message || "Failed to import file" });
    }
  });
  app2.get("/api/companies", async (req, res) => {
    try {
      const companies2 = await storage.getAllCompanies();
      res.json(companies2);
    } catch (error) {
      res.status(500).json({ message: error.message });
    }
  });
  app2.get("/api/companies/:id", async (req, res) => {
    try {
      const company = await storage.getCompany(req.params.id);
      if (!company) {
        return res.status(404).json({ message: "Company not found" });
      }
      res.json(company);
    } catch (error) {
      res.status(500).json({ message: error.message });
    }
  });
  app2.get("/api/companies/:id/leads", async (req, res) => {
    try {
      const leads2 = await storage.getLeadsByCompany(req.params.id);
      res.json(leads2);
    } catch (error) {
      res.status(500).json({ message: error.message });
    }
  });
  app2.post("/api/companies", async (req, res) => {
    try {
      const validatedData = insertCompanySchema.parse(req.body);
      const company = await storage.createCompany(validatedData);
      res.status(201).json(company);
    } catch (error) {
      res.status(400).json({ message: error.message });
    }
  });
  app2.patch("/api/companies/:id", async (req, res) => {
    try {
      const validatedData = insertCompanySchema.parse(req.body);
      const company = await storage.updateCompany(req.params.id, validatedData);
      if (!company) {
        return res.status(404).json({ message: "Company not found" });
      }
      res.json(company);
    } catch (error) {
      res.status(400).json({ message: error.message });
    }
  });
  app2.delete("/api/companies/:id", async (req, res) => {
    try {
      const deleted = await storage.deleteCompany(req.params.id);
      if (!deleted) {
        return res.status(404).json({ message: "Company not found" });
      }
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ message: error.message });
    }
  });
  app2.get("/api/config", async (req, res) => {
    try {
      const config = getAllConfig(false);
      res.json(config);
    } catch (error) {
      res.status(500).json({ message: error.message });
    }
  });
  app2.post("/api/config", async (req, res) => {
    try {
      const updates = req.body;
      const validation = validateConfig(updates);
      if (!validation.valid) {
        return res.status(400).json({
          message: "Invalid configuration",
          errors: validation.errors
        });
      }
      const success = saveConfigToFile(updates);
      if (success) {
        res.json({
          success: true,
          message: "Configuration updated successfully. Some changes may require a server restart."
        });
      } else {
        res.status(500).json({
          message: "Failed to save configuration"
        });
      }
    } catch (error) {
      res.status(500).json({ message: error.message });
    }
  });
  app2.post("/api/migrate/inventory-schema", async (req, res) => {
    try {
      const { db: db2 } = await Promise.resolve().then(() => (init_db(), db_exports));
      const { sql: execSql } = await import("drizzle-orm");
      const migrationSQL = `
        -- Drop existing inventory table if exists
        DROP TABLE IF EXISTS inventory CASCADE;

        -- Create new inventory table with Excel column structure
        CREATE TABLE inventory (
          id VARCHAR PRIMARY KEY DEFAULT gen_random_uuid(),
          product_heading TEXT,
          product TEXT NOT NULL,
          boxes INTEGER DEFAULT 0,
          sq_ft_per_box TEXT DEFAULT '0',
          total_sq_ft TEXT DEFAULT '0',
          notes TEXT,
          created_at TIMESTAMP NOT NULL DEFAULT NOW(),
          updated_at TIMESTAMP NOT NULL DEFAULT NOW()
        );

        -- Create indexes for better performance
        CREATE INDEX idx_inventory_product ON inventory(product);
        CREATE INDEX idx_inventory_heading ON inventory(product_heading);
      `;
      await db2.execute(execSql.raw(migrationSQL));
      res.json({ success: true, message: "Inventory schema migration completed" });
    } catch (error) {
      console.error("Migration error:", error);
      res.status(500).json({ message: error.message });
    }
  });
  app2.get("/api/inventory", async (req, res) => {
    try {
      const items = await storage.getAllInventory();
      res.json(items);
    } catch (error) {
      res.status(500).json({ message: error.message });
    }
  });
  app2.get("/api/inventory/:id", async (req, res) => {
    try {
      const item = await storage.getInventoryItem(req.params.id);
      if (!item) {
        return res.status(404).json({ message: "Item not found" });
      }
      res.json(item);
    } catch (error) {
      res.status(500).json({ message: error.message });
    }
  });
  app2.post("/api/inventory", async (req, res) => {
    try {
      const validated = insertInventorySchema.parse(req.body);
      const item = await storage.createInventoryItem(validated);
      res.json(item);
    } catch (error) {
      res.status(400).json({ message: error.message });
    }
  });
  app2.put("/api/inventory/:id", async (req, res) => {
    try {
      const validated = insertInventorySchema.parse(req.body);
      const item = await storage.updateInventoryItem(req.params.id, validated);
      if (!item) {
        return res.status(404).json({ message: "Item not found" });
      }
      res.json(item);
    } catch (error) {
      res.status(400).json({ message: error.message });
    }
  });
  app2.delete("/api/inventory/:id", async (req, res) => {
    try {
      const deleted = await storage.deleteInventoryItem(req.params.id);
      if (!deleted) {
        return res.status(404).json({ message: "Item not found" });
      }
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ message: error.message });
    }
  });
  app2.post("/api/inventory/bulk-delete", async (req, res) => {
    try {
      const { ids } = req.body;
      if (!Array.isArray(ids)) {
        return res.status(400).json({ message: "Invalid request: ids must be an array" });
      }
      const count = await storage.deleteInventoryItems(ids);
      res.json({ success: true, count });
    } catch (error) {
      res.status(500).json({ message: error.message });
    }
  });
  app2.post("/api/inventory/import", upload.single("file"), async (req, res) => {
    try {
      if (!req.file) {
        return res.status(400).json({ message: "No file uploaded" });
      }
      const targetCategory = req.query.category || null;
      console.log(`
========== INVENTORY IMPORT DEBUG ==========`);
      console.log(`\u{1F4C1} Query params:`, req.query);
      console.log(`\u{1F4C1} Target category: "${targetCategory}"`);
      console.log(`\u{1F4C1} Is targetCategory truthy?`, !!targetCategory);
      console.log(`\u{1F4C1} Target category type:`, typeof targetCategory);
      console.log(`===========================================
`);
      const workbook = XLSX.read(req.file.buffer, { type: "buffer" });
      const sheetName = workbook.SheetNames[0];
      const worksheet = workbook.Sheets[sheetName];
      const rawData = XLSX.utils.sheet_to_json(worksheet);
      console.log(`\u{1F4CA} Processing ${rawData.length} rows from inventory Excel file`);
      const items = [];
      let currentHeading = null;
      for (let i = 0; i < rawData.length; i++) {
        const row = rawData[i];
        const rowNumber = i + 2;
        const getColumnValue = (possibleNames) => {
          for (const name of possibleNames) {
            const value = row[name];
            if (value !== void 0 && value !== null && value !== "") {
              return String(value).trim();
            }
          }
          return void 0;
        };
        const product = getColumnValue(["PRODUCT", "Product", "product"]);
        if (!product || product === "") {
          continue;
        }
        const boxes = getColumnValue(["Boxes", "boxes", "BOXES"]);
        const sqFtBox = getColumnValue(["Sq Ft/box", "sq_ft_box", "Sq Ft/Box", "SQ FT/BOX"]);
        if (targetCategory) {
          if (!boxes && !sqFtBox) {
            console.log(`\u23ED\uFE0F  [TARGET MODE] Skipping heading row: ${product}`);
            continue;
          }
        } else {
          if (!boxes && !sqFtBox) {
            currentHeading = product;
            console.log(`\u{1F4CB} [EXCEL MODE] Section Header: ${currentHeading}`);
            continue;
          }
        }
        const boxesValue = boxes || null;
        const sqFtBoxValue = sqFtBox || null;
        const totalSqFt = getColumnValue(["Tot Sq Ft", "total_sq_ft", "Total Sq Ft", "TOT SQ FT"]) || null;
        let productName = product;
        let notes = null;
        const notesMatch = product.match(/\(([^)]+)\)/);
        if (notesMatch) {
          notes = notesMatch[1];
          productName = product.replace(/\s*\([^)]+\)\s*/g, "").trim();
        }
        let finalCategory;
        if (targetCategory) {
          finalCategory = targetCategory;
        } else {
          finalCategory = currentHeading;
        }
        const item = {
          productHeading: finalCategory,
          product: productName,
          boxes: boxesValue,
          sqFtPerBox: sqFtBoxValue,
          totalSqFt,
          notes
        };
        console.log(`\u2705 Row ${rowNumber}: "${item.product}" \u2192 Category: "${item.productHeading}" ${targetCategory ? "[FORCED]" : "[FROM EXCEL]"}`);
        items.push(item);
      }
      if (items.length === 0) {
        return res.status(400).json({
          message: "No valid items found. Ensure your Excel has 'PRODUCT' and 'Boxes' columns with data."
        });
      }
      console.log(`\u2705 Found ${items.length} valid items to import`);
      const validatedItems = items.map((item) => insertInventorySchema.parse(item));
      const createdItems = await storage.createInventoryItems(validatedItems);
      console.log(`\u{1F389} Successfully imported ${createdItems.length} items`);
      res.json({
        success: true,
        total: items.length,
        imported: createdItems.length
      });
    } catch (error) {
      console.error("\u274C Error importing inventory file:", error);
      res.status(400).json({ message: error.message || "Failed to import file" });
    }
  });
  app2.post("/api/migrate-inventory", async (req, res) => {
    try {
      console.log("\u{1F527} Running inventory schema migration...");
      await db.execute(sql2`DROP TABLE IF EXISTS inventory CASCADE`);
      console.log("\u2705 Dropped old inventory table");
      await db.execute(sql2`
        CREATE TABLE inventory (
          id SERIAL PRIMARY KEY,
          product TEXT NOT NULL,
          boxes TEXT,
          sq_ft_per_box TEXT,
          total_sq_ft TEXT,
          product_heading TEXT,
          notes TEXT,
          created_at TIMESTAMP NOT NULL DEFAULT NOW(),
          updated_at TIMESTAMP NOT NULL DEFAULT NOW()
        )
      `);
      console.log("\u2705 Created new inventory table");
      await db.execute(sql2`CREATE INDEX idx_inventory_product ON inventory(product)`);
      await db.execute(sql2`CREATE INDEX idx_inventory_product_heading ON inventory(product_heading)`);
      console.log("\u2705 Created indexes");
      res.json({ success: true, message: "Migration completed successfully" });
    } catch (error) {
      console.error("\u274C Migration failed:", error);
      res.status(500).json({ success: false, message: error.message });
    }
  });
  app2.post("/api/migrate/add-notes-to-leads", async (req, res) => {
    try {
      console.log("\u{1F504} Running migration: add notes column to leads table");
      const result = await db.execute(sql2`
        SELECT column_name 
        FROM information_schema.columns 
        WHERE table_name = 'leads' AND column_name = 'notes'
      `);
      if (result.rows && result.rows.length > 0) {
        console.log("\u2139\uFE0F Notes column already exists");
        return res.json({ success: true, message: "Notes column already exists" });
      }
      await db.execute(sql2`
        ALTER TABLE leads 
        ADD COLUMN notes TEXT
      `);
      console.log("\u2705 Successfully added notes column to leads table");
      res.json({ success: true, message: "Migration completed successfully" });
    } catch (error) {
      console.error("\u274C Migration failed:", error);
      res.status(500).json({ success: false, message: error.message });
    }
  });
  app2.get("/api/users", async (req, res) => {
    try {
      const { createClient } = await import("@supabase/supabase-js");
      const supabaseUrl = process.env.VITE_SUPABASE_URL || "";
      const supabaseServiceKey = process.env.SUPABASE_SERVICE_ROLE_KEY || "";
      if (!supabaseServiceKey) {
        return res.status(500).json({ message: "Supabase service key not configured" });
      }
      const supabaseAdmin = createClient(supabaseUrl, supabaseServiceKey);
      const { data, error } = await supabaseAdmin.auth.admin.listUsers();
      if (error) throw error;
      const users2 = data.users.map((user) => ({
        id: user.id,
        email: user.email,
        role: user.user_metadata?.role || "member",
        created_at: user.created_at,
        email_confirmed_at: user.email_confirmed_at
      }));
      res.json(users2);
    } catch (error) {
      console.error("Failed to fetch users:", error);
      res.status(500).json({ message: error.message });
    }
  });
  app2.post("/api/users", async (req, res) => {
    try {
      const { email, password, role, autoConfirm } = req.body;
      if (!email || !password) {
        return res.status(400).json({ message: "Email and password are required" });
      }
      if (password.length < 6) {
        return res.status(400).json({ message: "Password must be at least 6 characters" });
      }
      const { createClient } = await import("@supabase/supabase-js");
      const supabaseUrl = process.env.VITE_SUPABASE_URL || "";
      const supabaseServiceKey = process.env.SUPABASE_SERVICE_ROLE_KEY || "";
      if (!supabaseServiceKey) {
        return res.status(500).json({ message: "Supabase service key not configured" });
      }
      const supabaseAdmin = createClient(supabaseUrl, supabaseServiceKey);
      const { data, error } = await supabaseAdmin.auth.admin.createUser({
        email,
        password,
        email_confirm: autoConfirm,
        user_metadata: {
          role: role || "member"
        }
      });
      if (error) throw error;
      res.json({
        success: true,
        message: "User created successfully",
        user: {
          id: data.user.id,
          email: data.user.email,
          role: data.user.user_metadata?.role || "member"
        }
      });
    } catch (error) {
      console.error("Failed to create user:", error);
      res.status(500).json({ message: error.message });
    }
  });
  app2.delete("/api/users/:id", async (req, res) => {
    try {
      const { id } = req.params;
      const { createClient } = await import("@supabase/supabase-js");
      const supabaseUrl = process.env.VITE_SUPABASE_URL || "";
      const supabaseServiceKey = process.env.SUPABASE_SERVICE_ROLE_KEY || "";
      if (!supabaseServiceKey) {
        return res.status(500).json({ message: "Supabase service key not configured" });
      }
      const supabaseAdmin = createClient(supabaseUrl, supabaseServiceKey);
      const { error } = await supabaseAdmin.auth.admin.deleteUser(id);
      if (error) throw error;
      res.json({ success: true, message: "User deleted successfully" });
    } catch (error) {
      console.error("Failed to delete user:", error);
      res.status(500).json({ message: error.message });
    }
  });
  app2.get("/api/permissions/:userId", async (req, res) => {
    try {
      const { userId } = req.params;
      const permissions = await storage.getMemberPermissions(userId);
      res.json(permissions);
    } catch (error) {
      console.error("Failed to fetch permissions:", error);
      res.status(500).json({ message: error.message });
    }
  });
  app2.get("/api/permissions", async (req, res) => {
    try {
      const permissions = await storage.getAllMemberPermissions();
      res.json(permissions);
    } catch (error) {
      console.error("Failed to fetch all permissions:", error);
      res.status(500).json({ message: error.message });
    }
  });
  app2.put("/api/permissions/:userId", async (req, res) => {
    try {
      const { userId } = req.params;
      const { companyIds, canSeeInventory } = req.body;
      if (!Array.isArray(companyIds)) {
        return res.status(400).json({ message: "companyIds must be an array" });
      }
      const permissions = await storage.upsertMemberPermissions({
        userId,
        companyIds,
        canSeeInventory: canSeeInventory ?? false
      });
      res.json({ success: true, permissions });
    } catch (error) {
      console.error("Failed to update permissions:", error);
      res.status(500).json({ message: error.message });
    }
  });
  app2.delete("/api/permissions/:userId", async (req, res) => {
    try {
      const { userId } = req.params;
      const success = await storage.deleteMemberPermissions(userId);
      if (!success) {
        return res.status(404).json({ message: "Permissions not found" });
      }
      res.json({ success: true, message: "Permissions deleted successfully" });
    } catch (error) {
      console.error("Failed to delete permissions:", error);
      res.status(500).json({ message: error.message });
    }
  });
  const httpServer = createServer(app2);
  return httpServer;
}
var upload;
var init_routes = __esm({
  "server/routes.ts"() {
    "use strict";
    init_storage();
    init_db();
    init_schema();
    init_gmail();
    init_groq();
    init_config_manager();
    upload = multer({ storage: multer.memoryStorage() });
  }
});

// server/vite.ts
import express from "express";
import fs from "fs";
import path from "path";
function log(message, source = "express") {
  const formattedTime = (/* @__PURE__ */ new Date()).toLocaleTimeString("en-US", {
    hour: "numeric",
    minute: "2-digit",
    second: "2-digit",
    hour12: true
  });
  console.log(`${formattedTime} [${source}] ${message}`);
}
async function setupVite(app2, server) {
  const { createServer: createViteServer, createLogger } = await import("vite");
  const { nanoid } = await import("nanoid");
  const { default: react } = await import("@vitejs/plugin-react");
  const serverOptions = {
    middlewareMode: true,
    hmr: { server },
    allowedHosts: true
  };
  const viteLogger = createLogger();
  const vite = await createViteServer({
    // Minimal inline config for dev middleware
    configFile: false,
    root: path.resolve(import.meta.dirname, "..", "client"),
    appType: "custom",
    // Ensure JSX uses the automatic runtime so `import React` is not required
    esbuild: {
      jsx: "automatic",
      jsxImportSource: "react"
    },
    plugins: [react()],
    resolve: {
      alias: {
        "@": path.resolve(import.meta.dirname, "..", "client", "src"),
        "@shared": path.resolve(import.meta.dirname, "..", "shared"),
        "@assets": path.resolve(import.meta.dirname, "..", "attached_assets")
      }
    },
    customLogger: {
      ...viteLogger,
      error: (msg, options) => {
        viteLogger.error(msg, options);
        process.exit(1);
      }
    },
    server: serverOptions
  });
  app2.use(vite.middlewares);
  app2.use("*", async (req, res, next) => {
    const url = req.originalUrl;
    try {
      const clientTemplate = path.resolve(
        import.meta.dirname,
        "..",
        "client",
        "index.html"
      );
      let template = await fs.promises.readFile(clientTemplate, "utf-8");
      template = template.replace(
        `src="/src/main.tsx"`,
        `src="/src/main.tsx?v=${nanoid()}"`
      );
      const page = await vite.transformIndexHtml(url, template);
      res.status(200).set({ "Content-Type": "text/html" }).end(page);
    } catch (e) {
      vite.ssrFixStacktrace(e);
      next(e);
    }
  });
}
function serveStatic(app2) {
  const distPath = path.resolve(import.meta.dirname, "public");
  if (!fs.existsSync(distPath)) {
    throw new Error(
      `Could not find the build directory: ${distPath}, make sure to build the client first`
    );
  }
  app2.use(express.static(distPath));
  app2.use("*", (_req, res) => {
    res.sendFile(path.resolve(distPath, "index.html"));
  });
}
var isDevelopment;
var init_vite = __esm({
  "server/vite.ts"() {
    "use strict";
    isDevelopment = process.env.NODE_ENV === "development";
  }
});

// server/index.ts
var index_exports = {};
__export(index_exports, {
  addEmailNotification: () => addEmailNotification,
  clearAllNotifications: () => clearAllNotifications,
  dismissNotification: () => dismissNotification,
  dismissNotificationsForLead: () => dismissNotificationsForLead,
  getRecentNotifications: () => getRecentNotifications
});
import "dotenv/config";
import express2 from "express";
import rateLimit from "express-rate-limit";
async function addEmailNotification(leadId, leadName, fromEmail, subject) {
  const { storage: storage2 } = await Promise.resolve().then(() => (init_storage(), storage_exports));
  const notificationData = {
    id: `notif-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
    leadId,
    leadName,
    fromEmail,
    subject,
    isDismissed: false,
    createdAt: /* @__PURE__ */ new Date(),
    dismissedAt: null
  };
  const notification = await storage2.createNotification(notificationData);
  console.log(`\u{1F514} BACKEND: Created notification ${notification.id} for lead ${leadName} (${leadId})`);
  console.log(`   Total notifications in queue: ${await storage2.getRecentNotifications().then((n) => n.length)}`);
  console.log(`   Dismissed notifications: 0`);
  return notification;
}
async function getRecentNotifications(since) {
  const { storage: storage2 } = await Promise.resolve().then(() => (init_storage(), storage_exports));
  const notifications2 = await storage2.getRecentNotifications(since);
  console.log(`\u{1F4CA} BACKEND: Getting notifications - Total: ${notifications2.length}, After filtering dismissed: ${notifications2.length}`);
  const latestByLead = /* @__PURE__ */ new Map();
  for (const n of notifications2) {
    const existing = latestByLead.get(n.leadId);
    if (!existing || new Date(n.createdAt) > new Date(existing.createdAt)) {
      latestByLead.set(n.leadId, n);
    }
  }
  const result = Array.from(latestByLead.values());
  console.log(`   Notification IDs: ${result.map((n) => n.id).join(", ")}`);
  return result.sort(
    (a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
  );
}
async function dismissNotification(notificationId) {
  const { storage: storage2 } = await Promise.resolve().then(() => (init_storage(), storage_exports));
  await storage2.dismissNotification(notificationId);
  console.log(`\u{1F515} BACKEND: Dismissed notification: ${notificationId}`);
}
async function dismissNotificationsForLead(leadId) {
  const { storage: storage2 } = await Promise.resolve().then(() => (init_storage(), storage_exports));
  const count = await storage2.dismissNotificationsByLead(leadId);
  console.log(`\u{1F515} BACKEND: Dismissed ${count} notifications for lead: ${leadId}`);
}
async function clearAllNotifications() {
  const { storage: storage2 } = await Promise.resolve().then(() => (init_storage(), storage_exports));
  const count = await storage2.cleanupOldNotifications();
  log(`\u{1F9F9} Cleaned up ${count} old dismissed notifications`);
}
function startEmailSyncJob() {
  const SYNC_INTERVAL = 30 * 1e3;
  let lastSyncTime = new Date(Date.now() - 48 * 60 * 60 * 1e3).toISOString();
  log("\u{1F4E7} Email sync job started (checking every 30 seconds, 48h lookback)");
  const syncEmails = async () => {
    try {
      const { fetchNewEmails: fetchNewEmails2, getInReplyToHeader: getInReplyToHeader2, getEmailBody: getEmailBody2, getHeader: getHeader2, isGmailConfigured: isGmailConfigured2 } = await Promise.resolve().then(() => (init_gmail(), gmail_exports));
      const { storage: storage2 } = await Promise.resolve().then(() => (init_storage(), storage_exports));
      const { insertEmailSchema: insertEmailSchema2 } = await Promise.resolve().then(() => (init_schema(), schema_exports));
      if (!isGmailConfigured2()) {
        return;
      }
      log(`\u{1F50D} Checking for new emails since ${new Date(lastSyncTime).toLocaleString()}`);
      const newEmails = await fetchNewEmails2(lastSyncTime);
      let savedCount = 0;
      if (newEmails.length > 0) {
        log(`\u{1F4EC} Found ${newEmails.length} emails to process`);
      }
      for (const email of newEmails) {
        const fromAddress = getHeader2(email, "From");
        const subject = getHeader2(email, "Subject");
        const messageId = email.id;
        const threadId = email.threadId;
        log(`  \u{1F4E7} Processing email from: ${fromAddress}`);
        log(`     Subject: ${subject || "(No Subject)"}`);
        log(`     Message ID: ${messageId}`);
        log(`     Thread ID: ${threadId || "none"}`);
        if (!fromAddress) {
          log(`     \u26A0\uFE0F No from address, skipping`);
          continue;
        }
        const emailMatch = fromAddress.match(/<(.+?)>/) || [null, fromAddress];
        const cleanFromAddress = emailMatch[1] || fromAddress;
        const existing = await storage2.getEmailByMessageId(messageId);
        if (existing) {
          log(`     \u2139\uFE0F Email already exists in database, skipping`);
          continue;
        }
        let lead = null;
        const inReplyToHeader = getInReplyToHeader2(email);
        if (threadId) {
          log(`     \u{1F50D} Looking for existing email with thread ID: ${threadId}`);
          const relatedEmail = await storage2.getEmailByConversationId(threadId);
          if (relatedEmail) {
            log(`     \u2705 Found related email in thread, using lead: ${relatedEmail.leadId}`);
            lead = await storage2.getLead(relatedEmail.leadId);
          }
        }
        if (!lead) {
          log(`     \u{1F50D} No thread match, looking for lead by email address`);
          lead = await storage2.getLeadByEmail(cleanFromAddress);
        }
        if (lead) {
          log(`     \u2705 Matched to lead: ${lead.clientName} (${lead.id})`);
          log(`     \u{1F4BE} Saving new email to database...`);
          const emailBody = getEmailBody2(email);
          const emailData = insertEmailSchema2.parse({
            leadId: lead.id,
            subject: subject || "(No Subject)",
            body: emailBody || "",
            direction: "received",
            messageId,
            conversationId: threadId || null,
            fromEmail: cleanFromAddress,
            toEmail: process.env.EMAIL_FROM_ADDRESS || null,
            inReplyTo: inReplyToHeader
          });
          await storage2.createEmail(emailData);
          savedCount++;
          await storage2.updateLeadStatus(lead.id, "Replied");
          log(`     \u{1F4E8} Saved reply from ${cleanFromAddress} for lead ${lead.clientName}`);
          const notification = await addEmailNotification(lead.id, lead.clientName, cleanFromAddress, subject || "(No Subject)");
          log(`     \u{1F514} Created notification ${notification.id} for ${lead.clientName}`);
          const notificationCount = await storage2.getRecentNotifications().then((n) => n.length);
          log(`     \u{1F514} Total notifications in queue: ${notificationCount}`);
        } else {
          log(`     \u26A0\uFE0F No matching lead found for email: ${cleanFromAddress}`);
        }
      }
      if (savedCount > 0) {
        log(`\u2705 Email sync: ${savedCount} new replies saved and ${savedCount} notifications created`);
      } else if (newEmails.length > 0) {
        log(`\u2139\uFE0F  Email sync: ${newEmails.length} emails checked, none were new or matched leads`);
      }
      lastSyncTime = (/* @__PURE__ */ new Date()).toISOString();
    } catch (error) {
      log(`\u274C Email sync error: ${error.message}`);
      console.error(error);
    }
  };
  setTimeout(syncEmails, 5e3);
  setInterval(syncEmails, SYNC_INTERVAL);
}
var app, apiLimiter, authLimiter;
var init_index = __esm({
  "server/index.ts"() {
    init_routes();
    init_vite();
    init_config_manager();
    app = express2();
    apiLimiter = rateLimit({
      windowMs: 15 * 60 * 1e3,
      // 15 minutes
      max: 100,
      // Limit each IP to 100 requests per windowMs
      message: "Too many requests from this IP, please try again later",
      standardHeaders: true,
      // Return rate limit info in `RateLimit-*` headers
      legacyHeaders: false,
      // Disable `X-RateLimit-*` headers
      skip: (req) => {
        return !req.path.startsWith("/api");
      }
    });
    authLimiter = rateLimit({
      windowMs: 15 * 60 * 1e3,
      max: 5,
      message: "Too many login attempts, please try again later",
      skipSuccessfulRequests: true
      // Don't count successful requests
    });
    app.use("/api/", apiLimiter);
    app.use("/api/login", authLimiter);
    app.use("/api/register", authLimiter);
    app.use(express2.json({
      verify: (req, _res, buf) => {
        req.rawBody = buf;
      }
    }));
    app.use(express2.urlencoded({ extended: false }));
    app.use((req, res, next) => {
      const start = Date.now();
      const path2 = req.path;
      let capturedJsonResponse = void 0;
      const originalResJson = res.json;
      res.json = function(bodyJson, ...args) {
        capturedJsonResponse = bodyJson;
        return originalResJson.apply(res, [bodyJson, ...args]);
      };
      res.on("finish", () => {
        const duration = Date.now() - start;
        if (path2.startsWith("/api")) {
          let logLine = `${req.method} ${path2} ${res.statusCode} in ${duration}ms`;
          if (capturedJsonResponse) {
            logLine += ` :: ${JSON.stringify(capturedJsonResponse)}`;
          }
          if (logLine.length > 80) {
            logLine = logLine.slice(0, 79) + "\u2026";
          }
          log(logLine);
        }
      });
      next();
    });
    (async () => {
      await initializeConfig();
      log("\u2705 Configuration system initialized");
      const server = await registerRoutes(app);
      app.use((err, _req, res, _next) => {
        const status = err.status || err.statusCode || 500;
        const message = err.message || "Internal Server Error";
        res.status(status).json({ message });
        throw err;
      });
      const isDev = (process.env.NODE_ENV || app.get("env")) === "development";
      if (isDev) {
        try {
          await setupVite(app, server);
        } catch (e) {
          log(`Vite dev middleware not available (${e?.message || e}). Falling back to static serving.`, "vite");
          serveStatic(app);
        }
      } else {
        serveStatic(app);
      }
      const port = parseInt(process.env.PORT || "5000", 10);
      server.listen(port, () => {
        log(`serving on port ${port}`);
      });
      startEmailSyncJob();
    })();
  }
});
init_index();
export {
  addEmailNotification,
  clearAllNotifications,
  dismissNotification,
  dismissNotificationsForLead,
  getRecentNotifications
};
